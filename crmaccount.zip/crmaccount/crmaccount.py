# Copyright (c) 2026, Frappe Technologies Pvt. Ltd. and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class CRMAccount(Document):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		acc_completed: DF.Percent
		account_category: DF.Literal["Domestic Buyer", "International Buyer", "Domestic Supplier", "International Supplier", "Logistic Partner"]
		account_name: DF.Data
		account_source: DF.Literal["Email", "Facebook", "Google", "Instagram", "Interakt", "ITAD Conference", "Lead Boats", "LinkedIn", "PC Exporters", "Pinterest", "Quora", "Reddit", "Reference", "The Broker Site", "Trade Loop", "Twitter (X)", "Website", "Whatsapp", "Zoominfo"]
		account_status: DF.Literal["Qualified", "Red Flag", "Unqualified", "Business Closed"]
		account_type: DF.Link | None
		bank_details: DF.Check
		billing_address: DF.SmallText | None
		brand: DF.Literal["Acer", "Alcatel", "Apple", "Asus", "Broadway", "ByteSpeed", "Cisco", "Dell", "Fujitsu", "Gateway", "HGST", "Hitachi", "HP", "Hynix", "Huawei", "IBM", "I-Book", "Intel", "Lenovo", "Logitech", "Micron", "Microsoft", "Mix", "MSI", "NEC", "Nvidia", "Panasonic", "Samsung", "Seagate", "Siemon", "Sony", "Toshiba", "Transcend", "WD", "Nokia", "Other"]
		com_reg_trade_lic: DF.Check
		contact_verified: DF.Check
		customer_portal: DF.Check
		dba: DF.Data | None
		deal_category: DF.Literal["AC Adapters", "AIO", "Audio Accessories", "Barcode Scanner", "Barebone/Scrap Desktops", "Barebone/Scrap Laptops", "Cable Assemblies", "Camera", "CCTV/DVR", "Chromebook", "CPU", "CPU Fan", "Desktop C2D", "Desktop I Series", "Docking Stations", "Energy Audit Equipment", "E-Scrap", "Fax Machine", "Gaming PC/Consoles", "HDD", "HighEnd Desktops", "HighEnd Laptops", "iMac", "iPads", "iPhones", "IP Phone", "Keyboard", "Laptop C2D", "Laptop I Series", "LCD", "MacBooks", "MacMini", "Memory", "Mobiles", "Mouse", "Networking Equipment", "Phone", "POS", "Power Cable", "Printers", "RAM", "Router", "Servers / Rack Servers", "Solar Panel", "Speakers", "Stylus", "Switch Board", "Tablet", "Thin Clients", "Toner/Cartridges", "Video Cards", "Wearables", "Workstation", "Other"]
		description: DF.SmallText | None
		industry: DF.Literal["Apparel", "Banking", "Biotechnology", "Chemicals", "Communications", "Construction", "Consulting", "Education", "Electronics", "Energy", "Engineering", "Entertainment", "Environmental", "Finance", "Food & Beverage", "Government", "Healthcare", "Hospitality", "Insurance", "Machinery", "Manufacturing", "Media", "Not-for-profit", "Other", "Recreation", "Retail", "Shipping", "Technology", "Telecommunication", "Transportation", "Utilities", "Recycling", "DM Team"]
		inward_account: DF.Check
		payment_mode: DF.Literal["Bank(UAE)", "Bank(USA)", "Facility Payment"]
		phone: DF.Data | None
		profile: DF.SmallText | None
		prospect: DF.Check
		ready_for_transfer: DF.SmallText | None
		review_check: DF.Check
		share_this_account: DF.Check
		shipping_address: DF.SmallText | None
		standard: DF.Literal["R2", "R2V3", "Not Certified"]
		star_rating: DF.Literal["1", "2", "3", "4", "5"]
		type: DF.Literal["Analyst", "Competitor", "Customer", "Integrator", "Investor", "Partner", "Press", "Prospect", "Reseller", "Other"]
		video_verification: DF.Check
		website: DF.Data | None
	# end: auto-generated types
	pass
